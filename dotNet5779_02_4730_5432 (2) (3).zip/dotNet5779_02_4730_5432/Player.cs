﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dotNet5779_02_4730_5432
{
    class Player 
    {
        public Player(string _player_Name)
        {
           player_Name = _player_Name;
        }

        public string player_Name
        {
            get;
            set;
        }

        public int Count
        {
            get
            {
                return player_CardStock.Count;
            }
        }


        Queue<Card> player_CardStock= new Queue<Card>();
        

        public void addCards(IEnumerable<Card> cards)
        {
            foreach (Card c in cards)
                player_CardStock.Enqueue(c);
        }

        public void addCard(params Card[] cards)
        {
            addCards(new List<Card>(cards));
        }

        override public string ToString()
        {
            string result = string.Format("Name: {0}\n Cards: {1}\n", player_Name, player_CardStock.Count);
            foreach (Card c in player_CardStock)
                result += c.ToString() + "\n";
            return result;
        }

        public bool lose()
        {
            if (player_CardStock.Count==0)
                return true;
            return false;
        }

        public Card get_headCard()
        {
            return player_CardStock.Dequeue();
        }


    }
}
