﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace dotNet5779_02_4730_5432
{
    class CardStock : IEnumerable<Card>
    {
        List<Card> Cards = new List<Card>();
        Card temp;
        public CardStock()
        {
            //Init a cardstock
            //contain from all types one for the 2 colors           
            for (int i = 2; i <= 14; i++)
                for (int j = 0; j < 2; j++)
                    Cards.Add(new Card((E_Color)j, i));

        }
        public void Hash()
        {
            //Card mix function .
            Random r = new Random();
            for (int i = 0; i < 26; i++)
            {
                int x = r.Next(0, 26);
                int y = r.Next(0, 26);
                
                temp=Cards[x];
                Cards[x]= Cards[y];
                Cards[y] = temp;
            }
        }



        public override string ToString()
        {
            string AllCards = Cards[0].CardName;
            for (int i = 1; i < 26; i++)
            {
                AllCards += "\n";
                AllCards += Cards[i].CardName;
            }
            return AllCards;
        }
        public void addCard(Card _Card)
        {
            Cards.Add(_Card);
        } 

        public void distribute(params Player[] players)
        {
            int i = 0;
            while (i < Cards.Count)
                foreach (Player p in players)
                {
                    p.addCard(Cards[i]);
                    i++;
                }
            Cards.Clear();

        }

        public IEnumerator<Card> GetEnumerator()
        {
            return Cards.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        public Card this[string n]
        {
            get
            {
                foreach (Card c in Cards)
                    if (c.CardName == n)
                        return c;
                return null;
            }
        }

        public void Sort()
        {
            Cards.Sort();
        }
       

        public void removeCard(Card _Card)
        {
            Cards.Remove(_Card);
        }
    }
}






