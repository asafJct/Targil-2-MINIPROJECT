﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dotNet5779_02_4730_5432
{
    class Game
    {
        CardStock deck= new CardStock() ; //c'ctor Init deck such that contains Cards.
        public Player player1 = new Player("Player 1");
        public Player player2= new Player("Player 2");
        public void startGame() {
            deck.Hash();
            deck.distribute(player1,player2);
        }

        public string Winner()
        {
            if (player1.lose())
                return player1.player_Name;
            if (player1.lose())
                return player1.player_Name;
            return "No one won yet.";
        }

        public bool End()
        {
            return Winner() != "No one won yet.";
        }

        public void Move()
        {
            Move(new Queue<Card>());
        }

        public void Move(Queue<Card> deck)
        {
            if (!OverCards(player1, player2, deck))
            {
                Card c1 = player1.get_headCard();
                Card c2 = player2.get_headCard();
                deck.Enqueue(c1);
               deck.Enqueue(c2);
                if (c1.CompareTo(c2) > 0)
                    player1.addCards(deck);
                else if (c2.CompareTo(c1) > 0)
                    player2.addCards(deck);
                else if (!OverCards(player1, player2, deck))
                {

                    deck.Enqueue(player1.get_headCard());
                    deck.Enqueue(player2.get_headCard());
                    Move(deck);

                }
            }
        }

        override public string ToString()
        {
            return string.Format("{0}: {1} cards\n{2}: {3} cards\n",
                player1.player_Name, player1.Count, player2.player_Name, player2.Count);
        }

        //
        private bool OverCards(Player player1, Player player2, Queue<Card> pile)
        {
            if (player1.Count == 0)
                player2.addCards(pile);
            else if (player2.Count == 0)
                player1.addCards(pile);
            else
                return false;
            return true;
        }
    }

        
    }

