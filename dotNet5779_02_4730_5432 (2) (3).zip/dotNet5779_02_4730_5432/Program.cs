﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dotNet5779_02_4730_5432 {
    class MainProgram
    {
        static void Main(string[] args)
        {
            
           
                var g = new Game();
                g.startGame();
                Console.WriteLine(g.player1.ToString());
                Console.WriteLine(g.player2.ToString());
                Console.WriteLine(g);
            Console.WriteLine("enter 0 or 1");
            int option = int.Parse(Console.ReadLine());//operator code
                if (option == 0)
                {
                    int i = 0;
                    while (g.End() != true)
                    {
                        g.Move();
                        Console.WriteLine(g);
                        i++;
                    }
                    Console.WriteLine("The winner is {0}, it took {1} turns.", g.Winner(), i);
                }
            int j = 0;
            if (option == 1)
                {
                    if (g.End() != true)
                    {
                        g.Move();
                        Console.WriteLine(g);
                    j++;
                    }
                }


            //if option =1 , we have to continue 
            while (option == 1 || !(g.End()))
            {
                Console.WriteLine("enter 0 or 1");
                int option1 = int.Parse(Console.ReadLine());//operator code
                if (option1 == 0)
                {
                    while (g.End()!= true)
                    {
                        g.Move();
                        Console.WriteLine(g);
                        j++;
                    }
                    Console.WriteLine("The winner is {0}, it took {1} turns.", g.Winner(), j);
                }

                if (option1 == 1)
                {
                    if (g.End() != true)
                    {
                        g.Move();
                        Console.WriteLine(g);
                        j++;
                    }
                    else
                        Console.WriteLine("The winner is {0}, it took {1} turns.", g.Winner(), j);
                }
            }

            Console.ReadLine();
        }
    }
}
#region  Example of Haracha
//Name: Player 1
// Cards: 13
//red 4
//red Jack11
//black 5
//red King13
//black 9
//red 3
//red 8
//black 3
//red ace14
//red 6
//red 10
//black 10
//red 9

//Name: Player 2
// Cards: 13
//black 6
//black 2
//black 4
//black King13
//black Queen12
//black 7
//black Jack11
//red 2
//red 5
//black 8
//red 7
//red Queen12
//black ace14

//Player 1: 13 cards
//Player 2: 13 cards

//enter 0 or 1
//0
//Player 1: 12 cards
//Player 2: 14 cards

//Player 1: 13 cards
//Player 2: 13 cards

//Player 1: 14 cards
//Player 2: 12 cards

//Player 1: 11 cards
//Player 2: 15 cards

//Player 1: 10 cards
//Player 2: 16 cards

//Player 1: 11 cards
//Player 2: 15 cards

//Player 1: 12 cards
//Player 2: 14 cards

//Player 1: 11 cards
//Player 2: 15 cards

//Player 1: 12 cards
//Player 2: 14 cards

//Player 1: 11 cards
//Player 2: 15 cards

//Player 1: 10 cards
//Player 2: 16 cards

//Player 1: 11 cards
//Player 2: 15 cards

//Player 1: 10 cards
//Player 2: 16 cards

//Player 1: 9 cards
//Player 2: 17 cards

//Player 1: 8 cards
//Player 2: 18 cards

//Player 1: 7 cards
//Player 2: 19 cards

//Player 1: 6 cards
//Player 2: 20 cards

//Player 1: 7 cards
//Player 2: 19 cards

//Player 1: 6 cards
//Player 2: 20 cards

//Player 1: 7 cards
//Player 2: 19 cards

//Player 1: 6 cards
//Player 2: 20 cards

//Player 1: 7 cards
//Player 2: 19 cards

//Player 1: 6 cards
//Player 2: 20 cards

//Player 1: 7 cards
//Player 2: 19 cards

//Player 1: 6 cards
//Player 2: 20 cards

//Player 1: 7 cards
//Player 2: 19 cards

//Player 1: 6 cards
//Player 2: 20 cards

//Player 1: 7 cards
//Player 2: 19 cards

//Player 1: 4 cards
//Player 2: 22 cards

//Player 1: 5 cards
//Player 2: 21 cards

//Player 1: 4 cards
//Player 2: 22 cards

//Player 1: 5 cards
//Player 2: 21 cards

//Player 1: 4 cards
//Player 2: 22 cards

//Player 1: 5 cards
//Player 2: 21 cards

//Player 1: 4 cards
//Player 2: 22 cards

//Player 1: 5 cards
//Player 2: 21 cards

//Player 1: 4 cards
//Player 2: 22 cards

//Player 1: 5 cards
//Player 2: 21 cards

//Player 1: 4 cards
//Player 2: 22 cards

//Player 1: 5 cards
//Player 2: 21 cards

//Player 1: 4 cards
//Player 2: 22 cards

//Player 1: 5 cards
//Player 2: 21 cards

//Player 1: 4 cards
//Player 2: 22 cards

//Player 1: 5 cards
//Player 2: 21 cards

//Player 1: 4 cards
//Player 2: 22 cards

//Player 1: 5 cards
//Player 2: 21 cards

//Player 1: 4 cards
//Player 2: 22 cards

//Player 1: 3 cards
//Player 2: 23 cards

//Player 1: 4 cards
//Player 2: 22 cards

//Player 1: 1 cards
//Player 2: 25 cards

//Player 1: 0 cards
//Player 2: 26 cards

//The winner is Player 1, it took 51 turns.
//0
#endregion

#region
Name: Player 1
 Cards: 13
red 9
black Jack11
black 4
red 5
red 6
black 9
red 8
red ace14
black 7
black ace14
black 3
black 8
black Queen12

Name: Player 2
 Cards: 13
red 7
black 5
red Jack11
red 10
black King13
black 2
black 6
red 4
black 10
red 3
red 2
red Queen12
red King13

Player 1: 13 cards
Player 2: 13 cards

enter 0 or 1
1
Player 1: 14 cards
Player 2: 12 cards

enter 0 or 1

0
Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 16 cards
Player 2: 10 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 17 cards
Player 2: 9 cards

Player 1: 16 cards
Player 2: 10 cards

Player 1: 17 cards
Player 2: 9 cards

Player 1: 16 cards
Player 2: 10 cards

Player 1: 17 cards
Player 2: 9 cards

Player 1: 16 cards
Player 2: 10 cards

Player 1: 17 cards
Player 2: 9 cards

Player 1: 16 cards
Player 2: 10 cards

Player 1: 17 cards
Player 2: 9 cards

Player 1: 16 cards
Player 2: 10 cards

Player 1: 17 cards
Player 2: 9 cards

Player 1: 16 cards
Player 2: 10 cards

Player 1: 17 cards
Player 2: 9 cards

Player 1: 16 cards
Player 2: 10 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 12 cards
Player 2: 14 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 15 cards
Player 2: 11 cards

Player 1: 14 cards
Player 2: 12 cards

Player 1: 13 cards
Player 2: 13 cards

Player 1: 10 cards
Player 2: 16 cards

Player 1: 11 cards
Player 2: 15 cards

Player 1: 10 cards
Player 2: 16 cards

Player 1: 11 cards
Player 2: 15 cards

Player 1: 10 cards
Player 2: 16 cards

Player 1: 11 cards
Player 2: 15 cards

Player 1: 10 cards
Player 2: 16 cards

Player 1: 11 cards
Player 2: 15 cards

Player 1: 10 cards
Player 2: 16 cards

Player 1: 11 cards
Player 2: 15 cards

Player 1: 10 cards
Player 2: 16 cards

Player 1: 11 cards
Player 2: 15 cards

Player 1: 10 cards
Player 2: 16 cards

Player 1: 9 cards
Player 2: 17 cards

Player 1: 10 cards
Player 2: 16 cards

Player 1: 11 cards
Player 2: 15 cards

Player 1: 10 cards
Player 2: 16 cards

Player 1: 11 cards
Player 2: 15 cards

Player 1: 10 cards
Player 2: 16 cards

Player 1: 11 cards
Player 2: 15 cards

Player 1: 10 cards
Player 2: 16 cards

Player 1: 11 cards
Player 2: 15 cards

Player 1: 10 cards
Player 2: 16 cards

Player 1: 11 cards
Player 2: 15 cards

Player 1: 10 cards
Player 2: 16 cards

Player 1: 11 cards
Player 2: 15 cards

Player 1: 10 cards
Player 2: 16 cards

Player 1: 11 cards
Player 2: 15 cards

Player 1: 10 cards
Player 2: 16 cards

Player 1: 9 cards
Player 2: 17 cards

Player 1: 8 cards
Player 2: 18 cards

Player 1: 9 cards
Player 2: 17 cards

Player 1: 8 cards
Player 2: 18 cards

Player 1: 7 cards
Player 2: 19 cards

Player 1: 6 cards
Player 2: 20 cards

Player 1: 7 cards
Player 2: 19 cards

Player 1: 6 cards
Player 2: 20 cards

Player 1: 7 cards
Player 2: 19 cards

Player 1: 6 cards
Player 2: 20 cards

Player 1: 7 cards
Player 2: 19 cards

Player 1: 6 cards
Player 2: 20 cards

Player 1: 7 cards
Player 2: 19 cards

Player 1: 6 cards
Player 2: 20 cards

Player 1: 7 cards
Player 2: 19 cards

Player 1: 4 cards
Player 2: 22 cards

Player 1: 5 cards
Player 2: 21 cards

Player 1: 4 cards
Player 2: 22 cards

Player 1: 5 cards
Player 2: 21 cards

Player 1: 4 cards
Player 2: 22 cards

Player 1: 5 cards
Player 2: 21 cards

Player 1: 4 cards
Player 2: 22 cards

Player 1: 5 cards
Player 2: 21 cards

Player 1: 4 cards
Player 2: 22 cards

Player 1: 5 cards
Player 2: 21 cards

Player 1: 4 cards
Player 2: 22 cards

Player 1: 5 cards
Player 2: 21 cards

Player 1: 4 cards
Player 2: 22 cards

Player 1: 5 cards
Player 2: 21 cards

Player 1: 4 cards
Player 2: 22 cards

Player 1: 5 cards
Player 2: 21 cards

Player 1: 4 cards
Player 2: 22 cards

Player 1: 3 cards
Player 2: 23 cards

Player 1: 2 cards
Player 2: 24 cards

Player 1: 1 cards
Player 2: 25 cards

Player 1: 0 cards
Player 2: 26 cards

The winner is Player 1, it took 307 turns.
enter 0 or 1
#endregion
