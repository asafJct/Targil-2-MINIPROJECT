﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace dotNet5779_02_4730_5432
{
    public enum E_Color
    {
        red, black
    }

    public class Card : IComparable
    {

        private E_Color Color;
        private int number;

        public string CardName
        {
            get
            {
                if (number > 0 && number <= 10)
                    return number.ToString();

                else
                {
                    switch (number)
                    {
                        case 11:
                            return "Jack" + "11";

                        case 12:
                            return "Queen" + "12";
                        case 13:
                            return "King" + "13";

                        case 14:
                            return "ace" + "14";
                        default:
                            return " ";
                    }
                }

            }
        }



        public Card(E_Color _Color, int _number)
        {
            Color = _Color;
            //Have to make sur that num between 2-14
            if (_number > 1 && _number < 15)
                number = _number;
        }

        public override string ToString()
        {
            return Color + " " + CardName;
        }

        public int CompareTo(object obj)
        {
            Card s = (Card)obj;

            //sort by number, using CompareTo of the int type     
            return number.CompareTo(s.number);

            //return name.CompareTo(s.number); type
        }

    }
}




